package net.sppan.base.dao;

import net.sppan.base.dao.support.IBaseDao;
import net.sppan.base.entity.CustMaster;

import java.util.List;


public interface ICustDao extends IBaseDao<CustMaster, Integer> {
    CustMaster findCustByCMainRef(String cMainRef);

    List<CustMaster> findAll();

    List<CustMaster> findCustMasterByCMainRef(String cmainref);
}
