package net.sppan.base.dao;

import net.sppan.base.dao.support.IBaseDao;
import net.sppan.base.entity.WordCloud;

import java.util.List;

public interface IWordDao  extends IBaseDao<WordCloud, Integer> {

    List<WordCloud> findAll();
}
