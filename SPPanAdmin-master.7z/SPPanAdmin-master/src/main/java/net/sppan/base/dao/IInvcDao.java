package net.sppan.base.dao;

import net.sppan.base.dao.support.IBaseDao;
import net.sppan.base.entity.InvcMaster;

import java.util.List;

public interface IInvcDao extends IBaseDao<InvcMaster, Integer> {

    List<InvcMaster> findAll();


}
