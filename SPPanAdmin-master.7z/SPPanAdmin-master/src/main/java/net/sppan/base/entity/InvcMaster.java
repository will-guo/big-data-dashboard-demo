package net.sppan.base.entity;

import net.sppan.base.entity.support.BaseEntity;
import org.springframework.data.jpa.repository.Temporal;

import javax.persistence.*;
import java.sql.Date;


@Entity
@Table(name = "invc_master")
public class InvcMaster extends BaseEntity {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name="c_main_ref")
    private String cMainRef;

    @Column(name="ai_num")
    private String aiNum;

    @Column(name="ai_amt")
    private float aiAmt;

    @Column(name="int_amt")
    private float intAmt;

    @Column(name="charge_amt")
    private float chargeAmt;

    @Column(name="ai_dt")
    private Date aiDt;

    @Column(name="ai_due_dt")
    private Date aiDueDt;

    @Column(name="ai_ovd_fee")
    private float aiOvdFee;

    @Column(name="ai_set_dt")
    private Date aiSetDt;

    @Column(name="ai_stat_buyer_cd")
    private String aiStatBuyerCd;

    @Column(name="ai_stat_staff_cd")
    private String aiStatStaffCd;

    @Column(name="ai_stat_suplr_cd")
    private String aiStatSuplrCd;

    @Column(name="ai_upld_dt")
    private Date aiUpldDt;

    @Column(name="buyer_id")
    private String buyerId;

    @Column(name="buyer_nm")
    private String buyerNm;

    @Column(name="ccy")
    private String ccy;

    @Column(name="is_funded")
    private String isFunded;

    @Column(name="ovd_int_amt")
    private float ovdIntAmt;

    @Column(name="ovd_int_rate")
    private float ovdIntRate;

    @Column(name="suplr_id")
    private String suplrId;

    @Column(name="suplr_nm")
    private String suplrNm;

    @Column(name="ovd_dt")
    private Date ovdDt;

    @Column(name="ai_desc")
    private String aiDesc;

    @Column(name="good_desc")
    private String goodDesc;

    public String getcMainRef() {
        return cMainRef;
    }

    public void setcMainRef(String cMainRef) {
        this.cMainRef = cMainRef;
    }

    public String getAiNum() {
        return aiNum;
    }

    public void setAiNum(String aiNum) {
        this.aiNum = aiNum;
    }

    public float getAiAmt() {
        return aiAmt;
    }

    public void setAiAmt(float aiAmt) {
        this.aiAmt = aiAmt;
    }

    public float getIntAmt() {
        return intAmt;
    }

    public void setIntAmt(float intAmt) {
        this.intAmt = intAmt;
    }

    public float getChargeAmt() {
        return chargeAmt;
    }

    public void setChargeAmt(float chargeAmt) {
        this.chargeAmt = chargeAmt;
    }

    public Date getAiDt() {
        return aiDt;
    }

    public void setAiDt(Date aiDt) {
        this.aiDt = aiDt;
    }

    public Date getAiDueDt() {
        return aiDueDt;
    }

    public void setAiDueDt(Date aiDueDt) {
        this.aiDueDt = aiDueDt;
    }

    public float getAiOvdFee() {
        return aiOvdFee;
    }

    public void setAiOvdFee(float aiOvdFee) {
        this.aiOvdFee = aiOvdFee;
    }

    public Date getAiSetDt() {
        return aiSetDt;
    }

    public void setAiSetDt(Date aiSetDt) {
        this.aiSetDt = aiSetDt;
    }

    public String getAiStatBuyerCd() {
        return aiStatBuyerCd;
    }

    public void setAiStatBuyerCd(String aiStatBuyerCd) {
        this.aiStatBuyerCd = aiStatBuyerCd;
    }

    public String getAiStatStaffCd() {
        return aiStatStaffCd;
    }

    public void setAiStatStaffCd(String aiStatStaffCd) {
        this.aiStatStaffCd = aiStatStaffCd;
    }

    public String getAiStatSuplrCd() {
        return aiStatSuplrCd;
    }

    public void setAiStatSuplrCd(String aiStatSuplrCd) {
        this.aiStatSuplrCd = aiStatSuplrCd;
    }

    public Date getAiUpldDt() {
        return aiUpldDt;
    }

    public void setAiUpldDt(Date aiUpldDt) {
        this.aiUpldDt = aiUpldDt;
    }

    public String getBuyerId() {
        return buyerId;
    }

    public void setBuyerId(String buyerId) {
        this.buyerId = buyerId;
    }

    public String getBuyerNm() {
        return buyerNm;
    }

    public void setBuyerNm(String buyerNm) {
        this.buyerNm = buyerNm;
    }

    public String getCcy() {
        return ccy;
    }

    public void setCcy(String ccy) {
        this.ccy = ccy;
    }

    public String getIsFunded() {
        return isFunded;
    }

    public void setIsFunded(String isFunded) {
        this.isFunded = isFunded;
    }

    public float getOvdIntAmt() {
        return ovdIntAmt;
    }

    public void setOvdIntAmt(float ovdIntAmt) {
        this.ovdIntAmt = ovdIntAmt;
    }

    public float getOvdIntRate() {
        return ovdIntRate;
    }

    public void setOvdIntRate(float ovdIntRate) {
        this.ovdIntRate = ovdIntRate;
    }

    public String getSuplrId() {
        return suplrId;
    }

    public void setSuplrId(String suplrId) {
        this.suplrId = suplrId;
    }

    public String getSuplrNm() {
        return suplrNm;
    }

    public void setSuplrNm(String suplrNm) {
        this.suplrNm = suplrNm;
    }

    public Date getOvdDt() {
        return ovdDt;
    }

    public void setOvdDt(Date ovdDt) {
        this.ovdDt = ovdDt;
    }

    public String getAiDesc() {
        return aiDesc;
    }

    public void setAiDesc(String aiDesc) {
        this.aiDesc = aiDesc;
    }

    public String getGoodDesc() {
        return goodDesc;
    }

    public void setGoodDesc(String goodDesc) {
        this.goodDesc = goodDesc;
    }
}
