package net.sppan.base.entity;

import net.sppan.base.entity.support.BaseEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "word_cloud")
public class WordCloud extends BaseEntity {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name="w_id" ,nullable = false)
    private float wId;

    @Column(name="w_name")
    private String wName;

    @Column(name="w_count")
    private float wCount;

    public float getwId() {
        return wId;
    }

    public void setwId(float wId) {
        this.wId = wId;
    }

    public String getwName() {
        return wName;
    }

    public void setwName(String wName) {
        this.wName = wName;
    }

    public float getwCount() {
        return wCount;
    }

    public void setwCount(float wCount) {
        this.wCount = wCount;
    }
}
