package net.sppan.base.entity;

import net.sppan.base.entity.support.BaseEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "cust_master")
public class CustMaster extends BaseEntity {
    private static final long serialVersionUID = 1L;

    @Column(name="cust_nm")
    private String custNm;

    @Id
    @Column(name="c_main_ref",nullable = false)
    private String cMainRef;

    @Column(name="cust_type")
    private String custType;

    @Column(name="cust_add")
    private String custAdd;

    @Column(name="cust_add2")
    private String custAdd2;

    @Column(name="cust_mail")
    private String custMail;

    @Column(name="cust_post_cd")
    private String custPostCd;

    @Column(name="cust_state")
    private String custState;

    @Column(name="cust_tel")
    private String custTel;

    @Column(name="c_unit_code")
    private String cUnitCode;

    @Column(name="income_amt")
    private float incomeAmt;

    @Column(name="ov_amt")
    private float ovAmt;

    @Column(name="com_fund")
    private float comFund;

    @Column(name="rel_count")
    private float relCount;

    @Column(name="trx_amt")
    private float trxAmt;

    @Column(name="limit_amt")
    private float limitAmt;


    public float getIncomeAmt() {
        return incomeAmt;
    }

    public void setIncomeAmt(float incomeAmt) {
        this.incomeAmt = incomeAmt;
    }

    public float getOvAmt() {
        return ovAmt;
    }

    public void setOvAmt(float ovAmt) {
        this.ovAmt = ovAmt;
    }

    public float getComFund() {
        return comFund;
    }

    public void setComFund(float comFund) {
        this.comFund = comFund;
    }

    public float getRelCount() {
        return relCount;
    }

    public void setRelCount(float relCount) {
        this.relCount = relCount;
    }

    public float getTrxAmt() {
        return trxAmt;
    }

    public void setTrxAmt(float trxAmt) {
        this.trxAmt = trxAmt;
    }

    public float getLimitAmt() {
        return limitAmt;
    }

    public void setLimitAmt(float limitAmt) {
        this.limitAmt = limitAmt;
    }

    public String getCustNm() {
        return custNm;
    }

    public void setCustNm(String custNm) {
        this.custNm = custNm;
    }

    public String getcMainRef() {
        return cMainRef;
    }

    public void setcMainRef(String cMainRef) {
        this.cMainRef = cMainRef;
    }

    public String getCustType() {
        return custType;
    }

    public void setCustType(String custType) {
        this.custType = custType;
    }

    public String getCustAdd() {
        return custAdd;
    }

    public void setCustAdd(String custAdd) {
        this.custAdd = custAdd;
    }

    public String getCustAdd2() {
        return custAdd2;
    }

    public void setCustAdd2(String custAdd2) {
        this.custAdd2 = custAdd2;
    }

    public String getCustMail() {
        return custMail;
    }

    public void setCustMail(String custMail) {
        this.custMail = custMail;
    }

    public String getCustPostCd() {
        return custPostCd;
    }

    public void setCustPostCd(String custPostCd) {
        this.custPostCd = custPostCd;
    }

    public String getCustState() {
        return custState;
    }

    public void setCustState(String custState) {
        this.custState = custState;
    }

    public String getCustTel() {
        return custTel;
    }

    public void setCustTel(String custTel) {
        this.custTel = custTel;
    }

    public String getcUnitCode() {
        return cUnitCode;
    }

    public void setcUnitCode(String cUnitCode) {
        this.cUnitCode = cUnitCode;
    }
}
