package net.sppan.base.service;

import net.sppan.base.entity.CustMaster;
import net.sppan.base.service.support.IBaseService;

public interface ICustService extends IBaseService<CustMaster, Integer> {
}
