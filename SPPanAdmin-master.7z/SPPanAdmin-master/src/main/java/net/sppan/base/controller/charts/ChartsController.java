package net.sppan.base.controller.charts;

import net.sppan.base.controller.BaseController;
import net.sppan.base.dao.ICustDao;
import net.sppan.base.dao.IInvcDao;
import net.sppan.base.dao.IWordDao;
import net.sppan.base.entity.CustMaster;
import net.sppan.base.entity.InvcMaster;
import net.sppan.base.entity.WordCloud;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

//import java.sql.Date;
import java.util.Date;
import java.sql.ResultSet;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/admin/charts")
public class ChartsController extends BaseController{

    @Autowired
    private ICustDao iCustDao;

    @Autowired
    private IInvcDao iInvcDao;

    @Autowired
    private IWordDao iWordDao;

    @RequestMapping(value={"/custlist"})
    @ResponseBody
    public Map<String,String> custlist(@RequestParam(value="searchTest",required=false) String searchText){
        List<CustMaster> custList=iCustDao.findAll();
        Map<String,String> map=new HashMap<>();
        for (CustMaster custInfo :custList){
            map.put(custInfo.getcMainRef(),custInfo.getcUnitCode());
        }
        return map;
    }

    @RequestMapping(value={"/wordlist"})
    @ResponseBody
    public Map<String,Float> wordlist(@RequestParam(value="searchTest",required=false) String searchText){
        List<WordCloud> wordList=iWordDao.findAll();
        Map<String,Float> map=new HashMap<>();
        for (WordCloud wordInfo :wordList){
            map.put(wordInfo.getwName(),wordInfo.getwCount());
        }
        return map;
    }

    @RequestMapping(value={"/custimage"})
    @ResponseBody
    public Map<String,Float> custimage(@RequestParam(value="searchTest",required=false) String searchText){
        List<CustMaster> custList=iCustDao.findCustMasterByCMainRef("CNAPC001");
        Map<String,Float> map=new HashMap<>();
        for (CustMaster custInfo :custList){
           // map.put("CMref",custInfo.getcMainRef());
            map.put("Income",custInfo.getIncomeAmt());
            map.put("OVAmt",-custInfo.getOvAmt());
            map.put("CompFund",custInfo.getComFund());
            map.put("Relaship",custInfo.getRelCount());
            map.put("TrxAmt",custInfo.getTrxAmt());
            map.put("Limit",custInfo.getLimitAmt());
           // map.put()
        }
        return map;
    }

    @RequestMapping(value={"/invclist"})
    @ResponseBody
    public Map<String,Float> invclist(@RequestParam(value="searchTest",required=false) String searchText){
        float jan=0;
        float feb=0;
        float mar=0;
        float apr=0;
        float may=0;
        float jun=0;
        float jul=0;
        float aug=0;
        float sep=0;
        List<InvcMaster> invcList=iInvcDao.findAll();

        SimpleDateFormat mstr=new SimpleDateFormat("MM");
        float amt=0;
        for (InvcMaster invcInfo:invcList){
            amt= invcInfo.getAiAmt();
            Date d= null;
            try {
                d = new SimpleDateFormat("yyyy-MM-dd").parse(invcInfo.getAiDt().toString());
            } catch (ParseException e) {
                e.printStackTrace();
            }
            String mon=mstr.format(d);
            if ("01".equals(mon)){
                jan=jan+amt;
            }
            else if ("02".equals(mon)){
                feb=feb+amt;
            }
            else if ("03".equals(mon)){
                mar=mar+amt;
            }else if ("04".equals(mon)){
                apr=apr+amt;
            }else if ("05".equals(mon)){
                may=may+amt;
            }else if("06".equals(mon)){
                jun=jun+amt;
            }else if("07".equals(mon)){
                jul=jul+amt;
            }else if("08".equals(mon)){
                aug=aug+amt;
            }else {
                sep = sep + amt;
            }

        }
        Map<String,Float> map=new HashMap<>();
        map.put("01",jan);
        map.put("02",feb);
        map.put("03",mar);
        map.put("04",apr);
        map.put("05",may);
        map.put("06",jun);
        map.put("07",jul);
        map.put("08",aug);
        map.put("09",sep);
        return map;
    }

    @RequestMapping(value={"/intlist"})
    @ResponseBody
    public Map<String,Float> intlist(@RequestParam(value="searchTest",required=false) String searchText){
        float jan=0;
        float feb=0;
        float mar=0;
        float apr=0;
        float may=0;
        float jun=0;
        float jul=0;
        float aug=0;
        float sep=0;
        List<InvcMaster> invcList=iInvcDao.findAll();

        SimpleDateFormat mstr=new SimpleDateFormat("MM");
        float amt=0;
        for (InvcMaster invcInfo:invcList){
            amt= invcInfo.getIntAmt();
            Date d= null;
            try {
                d = new SimpleDateFormat("yyyy-MM-dd").parse(invcInfo.getAiDt().toString());
            } catch (ParseException e) {
                e.printStackTrace();
            }
            String mon=mstr.format(d);
            if ("01".equals(mon)){
                jan=jan+amt;
            }
            else if ("02".equals(mon)){
                feb=feb+amt;
            }
            else if ("03".equals(mon)){
                mar=mar+amt;
            }else if ("04".equals(mon)){
                apr=apr+amt;
            }else if ("05".equals(mon)){
                may=may+amt;
            }else if("06".equals(mon)){
                jun=jun+amt;
            }else if("07".equals(mon)){
                jul=jul+amt;
            }else if("08".equals(mon)){
                aug=aug+amt;
            }else {
                sep = sep + amt;
            }

        }
        Map<String,Float> map=new HashMap<>();
        map.put("01",jan);
        map.put("02",feb);
        map.put("03",mar);
        map.put("04",apr);
        map.put("05",may);
        map.put("06",jun);
        map.put("07",jul);
        map.put("08",aug);
        map.put("09",sep);
        return map;
    }

    @RequestMapping(value={"/custMaplist"})
    @ResponseBody
    public Map<String,Float> custMaplist(@RequestParam(value="searchTest",required=false) String searchText){
        float sh=0;
        float yn=0;
        float bj=0;
        float jl=0;
        float sc=0;
        float tj=0;
        float nx=0;
        float ah=0;
        float sd=0;
        float sx=0;
        float gd=0;
        float xj=0;
        float js=0;
        float jx=0;
        float hb=0;
        float hn=0;
        float hun=0;
        float fj=0;
        float ln=0;
        float sxi=0;
        List<CustMaster> custList=iCustDao.findAll();

        SimpleDateFormat mstr=new SimpleDateFormat("MM");
        float amt=0;
        String city;
        for (CustMaster custInfo:custList){
            amt= custInfo.getTrxAmt();
            city=custInfo.getCustState();
            if ("上海".equals(city)){
                sh=sh+amt;
            }
            else if ("云南".equals(city)){
                yn=yn+amt;
            }
            else if ("北京".equals(city)){
                bj=bj+amt;
            }else if ("吉林".equals(city)){
                jl=jl+amt;
            }else if ("四川".equals(city)){
                sc=sc+amt;
            }else if("天津".equals(city)){
                tj=tj+amt;
            }else if("宁夏".equals(city)){
                nx=nx+amt;
            }else if("安徽".equals(city)){
                ah=ah+amt;
            }else if("山东".equals(city)) {
                sd = sd + amt;
            }else if("山西".equals(city)) {
                sx = sx + amt;
            }else if("广东".equals(city)) {
                gd = gd + amt;
            }else if("新疆".equals(city)) {
                xj = xj + amt;
            }else if("江苏".equals(city)) {
                js = js + amt;
            }else if("江西".equals(city)) {
                jx = jx + amt;
            }else if("河北".equals(city)) {
                hb = hb + amt;
            }else if("河南".equals(city)) {
                hn = hn + amt;
            }else if("湖南".equals(city)) {
                hun = hun + amt;
            }else if("福建".equals(city)) {
                fj = fj + amt;
            }else if("辽宁".equals(city)) {
                ln = ln + amt;
            }else if("陕西".equals(city)) {
                sxi = sxi + amt;
            }else {
                gd = gd + amt;
            }

        }
        Map<String,Float> map=new HashMap<>();
        map.put("上海",sh);
        map.put("云南",yn);
        map.put("北京",bj);
        map.put("吉林",jl);
        map.put("四川",sc);
        map.put("天津",tj);
        map.put("宁夏",nx);
        map.put("安徽",ah);
        map.put("山东",sd);
        map.put("山西",sx);
        map.put("广东",gd);
        map.put("新疆",xj);
        map.put("江苏",js);
        map.put("江西",jx);
        map.put("河北",hb);
        map.put("河南",hn);
        map.put("湖南",hun);
        map.put("福建",fj);
        map.put("辽宁",ln);
        map.put("陕西",sxi);
        return map;
    }
    @RequestMapping("/index")
    public String index(){
        return "admin/charts/index";
    }

    @RequestMapping("/graph_plot")
    public String plot(){
        return "admin/charts/graph_plot";
    }

    @RequestMapping("/graph_radar")
    public String radar(){
        return "admin/charts/graph_radar";
    }
    @RequestMapping("/graph_map")
    public String map(){
        return "admin/charts/graph_map";
    }

    @RequestMapping("/graph_wordcloud")
    public String wordcloud(){
        return "admin/charts/graph_wordcloud";
    }


//    public void Test(){
//        String jpqlOrder = "SELECT o FROM OrderByAndGroupBy o ORDER BY o.id DESC";
//        Query createQuery = entityManager.createQuery(jpqlOrder);
//        List resultList = createQuery.getResultList();
//        System.out.println(resultList);
//
//    }

}
